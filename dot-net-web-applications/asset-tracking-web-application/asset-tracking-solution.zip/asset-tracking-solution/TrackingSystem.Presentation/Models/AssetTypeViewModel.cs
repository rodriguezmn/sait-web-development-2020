﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TrackingSystem.Presentation.Models
{
    public class AssetTypeViewModel
    {

        // use annotation for dispaly purposes 

        [Display(Name = "Asset Type")]
        public string Name { get; set; }

    }        
}
